﻿using System;
using Verse;

namespace AAA
{
    // Token: 0x02000010 RID: 16
    public class CompProjectileExtraDamage : ThingComp
    {
        // Token: 0x1700000E RID: 14
        // (get) Token: 0x0600002E RID: 46 RVA: 0x00002A85 File Offset: 0x00000C85
        public CompProperties_ProjectileExtraDamage Props
        {
            get
            {
                return (CompProperties_ProjectileExtraDamage)this.props;
            }
        }
    }
}
