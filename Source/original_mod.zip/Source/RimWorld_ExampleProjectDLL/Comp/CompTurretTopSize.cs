﻿using System;
using Verse;

    namespace AAA
    {
        // Token: 0x0200000C RID: 12
        public class CompTurretTopSize : ThingComp
        {
            // Token: 0x1700000B RID: 11
            // (get) Token: 0x0600001F RID: 31 RVA: 0x000025C0 File Offset: 0x000007C0
            public CompProperties_TurretTopSize Props
            {
                get
                {
                    return (CompProperties_TurretTopSize)this.props;
                }
            }
        }
    }
